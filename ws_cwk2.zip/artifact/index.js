function id() {
  return 'UP000000';
}

module.exports.id = id;
